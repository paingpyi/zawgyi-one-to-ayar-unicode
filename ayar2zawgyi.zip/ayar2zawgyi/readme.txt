﻿=== Plugin Name ===
Plugin Name: Ayar Unicode Converter
Plugin URI: http://www.ayarunicodegroup.com/
Description: Automatic unicode font converter for ayar and zawgyi font for burmese language. <a href="http://www.ayarunicodegroup.com/">Documentation</a>.
Author: Sithu Thwin
Contributors: Sithu Thwin and ...
Author URI: http://www.http://www.ayarunicodegroup.com/
Donate link: http://www.http://www.ayarunicodegroup.com/
Tags: Zawgyi-one, Ayar, Unicode, Converter
Version: 1.0
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 4.3

Zawgyi-one font to Ayar Unicode on the fly webpage-based converter.

== Description ==
This plugin is designed to convert all Zawgyi-one font to Ayar Unicode on the fly webpage-based converter on your WordPress powered site. On the fly webpage-based Convertor is an easy-to-use blog data plugin for WordPress. This utility is able to convert your contents to Ayar Unicode in a few seconds.

== Installation ==

1. Download the installation archive and uncompress
2. Upload the unarchived folder to your plugins directory (this is wp-content/plugins/)
3. Activate the plugin in your WordPress administration panel (this is the Plugins page)

== Frequently Asked Questions ==

you can read at http://club.ayarunicodegroup.org/

== Screenshots ==
1. This screen shot at http://i35.tinypic.com/dn1sgh.jpg
2. This is the second screen shot at http://i37.tinypic.com/2li9bp4.jpg

== Changelog ==

= Ver. 1.0 =

This version fixed to convert zawgyi-one font to ayar unicode font.

== Upgrade Notice ==
 if we can bug, we will Upgrade immediately.